x = {  'a':37,'b':42,
'c':927}
y = 'hello '+       'world'
class foo  (     object  ):
   def f    (self   ):
       z =3
       return       y **2
   def g(self, x,
       y=42
       ):
      # pylint: disable=missing-docstring
      return x--y
def f  (   a ) :
   return      37+-a[42-a :  y*3]  # noqa: E203
